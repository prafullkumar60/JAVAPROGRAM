import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution
{

 public static void main(String[] args)
 {
  Scanner sc=new Scanner(System.in);
  Song[] songs=new Song[5];
  for(int i=0;i<songs.length;i++)
  {
      int songId=sc.nextInt();sc.nextLine();
      String title=sc.nextLine();
      String artist=sc.nextLine();
      int rating=sc.nextInt();sc.nextLine();
       songs[i]=new Song(songId,title,artist,rating);
  }
  String artist1=sc.nextLine();
  String artist2=sc.nextLine();
  int output1=findAvgRatingForArtist(songs, artist1);
  if(output1>0)
  {
      System.out.println(output1);
  }
  else
  {
      System.out.println("There are no songs with the given artist");
  }
  Song[] output2=searchSongByArtist(artist2, songs);
  if(output2!=null)
  {
     for(int i=0;i<output2.length;i++)
     {
         System.out.println(output2[i].getSongId());
     }
  }
  else
  {
      System.out.println("There are no songs available for the given artist");
  }
 }

public static int findAvgRatingForArtist(Song[] song, String artist)
  {
   int cnt=0,sum=0;
    for(int i=0;i<song.length;i++)
    {
        if(song[i].getArtist().equalsIgnoreCase(artist))
        {
               sum+=song[i].getRating();
               cnt++; 
        }
    }
    if(cnt>0)
    {
        return sum/cnt;
    }
    else
    {
        return 0;
    }
  }

public static Song[] searchSongByArtist(String artist, Song[] song)
  {
    int cnt=0;
    for(int i=0;i<song.length;i++)
    {
        if(song[i].getArtist().equalsIgnoreCase(artist))
        {
            cnt++;
        }

    }
    if(cnt==0)
    {
        return null;
    }
    Song[] s=new Song[cnt];
    cnt=0;
    for(int i=0;i<song.length;i++)
    {
       if(song[i].getArtist().equalsIgnoreCase(artist))
       {
           s[cnt++]=song[i];
       } 
    }
    for(int i=0;i<s.length;i++)
    {
        for(int j=i+1;j<s.length;j++)
        {
            if(s[i].getSongId()<=s[j].getSongId())
            {
                Song temp=s[i];
                s[i]=s[j];
                s[j]=temp;
            }
        }
    }
    return s;
  }
}
    
class Song
{
  private int songId;
  private String title;
  private String artist;
  private int rating;
    public Song(int songId, String title, String artist, int rating) {
        super();
        this.songId = songId;
        this.title = title;
        this.artist = artist;
        this.rating = rating;
    }
    public int getSongId() {
        return songId;
    }
    public void setSongId(int songId) {
        this.songId = songId;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getArtist() {
        return artist;
    }
    public void setArtist(String artist) {
        this.artist = artist;
    }
    public int getRating() {
        return rating;
    }
    public void setRating(int rating) {
        this.rating = rating;
    }
}
